/* 
 * * Woocommerce Urbaner
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */
/*
function openGoogleMap(btn) {
    var currentTab = jQuery(btn).attr('data-attr-tab-id');
    // Initialize Dialog
    jQuery('#dialog').dialog({
        resizable: false,
        height: 'auto',
        width: 500,
        autoOpen: false,
        closeText: '',
        show: {
            effect: "blind",
            duration: 1000
        },
        hide: {
            effect: "explode",
            duration: 1000
        },
        buttons: {
            'Establecer': function() {
                var lat = jQuery(this).find('.geo_latitude').val();
                var lgt = jQuery(this).find('.geo_longitude').val();
                jQuery('#' + currentTab)
                        .find('#warehouse_latitude').val(lat).end()
                        .find('#warehouse_longitude').val(lgt).end();
                jQuery(this).dialog('close');
                console.log(currentTab);
            }
        }
    });
    jQuery('#dialog').dialog('open');
}
*/
jQuery(document).ready(function($) {
    $("#company").on('keyup', function () {
        $("#compania").val($(this).val());
    });
    /* Clear Hours */
    $(".clear-field").click(function() {
        $(this).prev().val("");
    });
    /* Warehouses */
    var dinamicTabs = {
        tabLinkHtml: tabLinkHtml,
        tabHtml: tabHtml,
        tabs: $("#tabs"),
        tabsLinks: $("#tabs").find(".tabs-links"),
        start: function() {
            this.tabsLinks.find("a button").click(dinamicTabs.removeTab);
            this.tabs.tabs();
            $("#add_tab").on("click", function() {
                dinamicTabs.addNewTab();
            });
        },
        getNumTabs: function() {
            return parseInt(this.tabs.attr("data-num-tabs"));
        },
        setNumTabs: function(numTabs) {
            this.tabs.attr("data-num-tabs", numTabs);
        },
        addNewTab: function() {
            var numTabs = this.getNumTabs();
            this.setNumTabs(numTabs + 1);
            this.tabsLinks.append($(this.tabLinkHtml)
                    .attr("id", "link-tabs-" + numTabs)
                    .find("a").attr("href", "#tabs-" + numTabs).end()
                    .find("a .warehouse-number").html("&nbsp;" + (numTabs+1)).end()
                    .find("a button").attr("data-tab-index", numTabs).click(dinamicTabs.removeTab).end()
            );
            var tabId = "tabs-" + numTabs;
            this.tabs.append($(this.tabHtml)
                    .attr("id", tabId)
                    .find(".showDialog").attr('data-attr-tab-id', tabId).end()
            );
            console.log(tabId);
            this.tabs.tabs("refresh");
            $("#link-tabs-" + numTabs + " a").trigger("click");
        },
        removeTab: function() {
            var index = parseInt($(this).attr("data-tab-index"));
            $("#link-tabs-" + index).remove();
            $("#tabs-" + index).remove();
            dinamicTabs.setNumTabs(dinamicTabs.getNumTabs() - 1);
            $("#link-tabs-" + (dinamicTabs.getNumTabs() - 1) + " a").trigger("click");
        }
    };
    dinamicTabs.start();
    /* holidays datime picker */
    var addDatePicker = function() {
        $(".holiday_date").datepicker({
            dateFormat: "MM dd",
            dayNamesMin: dayNamesMin,
            monthNames: monthNames
        });
    };
    $("#czContainer").czMore({
        onAdd: function() {
            addDatePicker();
        }
    });
    addDatePicker();
    // add timepicker to all fields that require it
    $(".time-text").datetimepicker({
        format: 'H:i',
        datepicker: false,
        lang: "es"
    });
    /* $('.time-text').timepicker( {
        showAnim: 'blind',
        hourText: "Horas",
        minuteText: "Minutos"
    }); */
    var toggle = function(checkSelector, inputSelector) {
        if($(checkSelector).is(":checked"))
            $(inputSelector).show();
        else
            $(inputSelector).hide();
    };
    $("input[name='skydropx_cost_of_shipping']").change(function() {
        toggle("#skydropx_flat_price", "#skydropx_flat_price_input");
    });
    toggle("#skydropx_flat_price", "#skydropx_flat_price_input");
    
});