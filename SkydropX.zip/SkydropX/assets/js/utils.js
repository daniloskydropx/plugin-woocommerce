/* script */

  (function($){

        $('#billing_postcode').change(function(){
          $(".typeshipping").prop("checked", false);
          console.log('address changed');
            jQuery('body').trigger('update_checkout');
        });
      })(jQuery);