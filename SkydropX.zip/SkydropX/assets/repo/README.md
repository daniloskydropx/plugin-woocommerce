# Vexsoluciones Woocommerce Urbaner Repo Assets #
https://www.pasarelasdepagos.com
Copyright (c) 2020 Vexsoluciones
Licensed under the GPLv2 license.

Assets such as screenshots and banner for WordPress.org plugin repository listing.