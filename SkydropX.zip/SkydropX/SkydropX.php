<?php
/**
 * Plugin Name: SkydropX
 * Plugin URI:  https://www.skydropx.com/
 * Description: El plugin de Skydropx para Woocommerce te permite conectar tu tienda online e-commerce con tu proveedor de Logística Skydropx en mínutos.
 * Version:     2.6
 * Author:      Vexsoluciones
 * Author URI:  https://www.pasarelasdepagos.com
 * Donate link: https://www.vexsoluciones.com/pasarelas-de-pago-plugins/
 * License:     GPLv2
 * Text Domain: vexsoluciones-woocommerce-skydropx
 * Domain Path: /languages
 *
 * @link    https://www.vexsoluciones.com/pasarelas-de-pago-plugins/
 *
 * @package SkydropX
 * @version 2.6
 *
 * Built using generator-plugin-wp (https://github.com/WebDevStudios/generator-plugin-wp)
 */

/**
 * Copyright (c) 2022 Vexsoluciones (email : ventas@vexsoluciones.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License, version 2 or, at
 * your discretion, any later version, as published by the Free
 * Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */


// Include additional php files here.
// require 'includes/something.php';

/**
 * Main initiation class.
 *
 * @since  1.0
 * error_reporting(E_ALL);
*ini_set('display_errors', '1');*/

function woocommerceSkydropxRequire($dir, $file) {
    $filesInIncludesDir = scandir($dir);
    foreach($filesInIncludesDir as $currentFileOrDir) {
        $path = realpath($dir . DIRECTORY_SEPARATOR . $currentFileOrDir);
        if(!is_dir($path)) {
            if($file == $currentFileOrDir) 
                require_once $path;
        } else if($currentFileOrDir != '.' && $currentFileOrDir != '..')
            woocommerceSkydropxRequire($path, $file);
    }
}

spl_autoload_register(function($classname) {
    $dir = __DIR__ . DIRECTORY_SEPARATOR . 'includes';
    $file = "{$classname}.php";
    woocommerceSkydropxRequire($dir, $file);
});

final class Vexsoluciones_Woocommerce_Skydropx {

	/**
	 * Current version.
	 *
	 * @var    string
	 * @since  1.0
	 */
	const VERSION = '1.9';
        const TEXT_DOMAIN = 'woocommerce-skydropx';
        const SKYDROPX_DIR = WP_CONTENT_DIR . "/plugins/SkydropX";
	/**
	 * URL of plugin directory.
	 *
	 * @var    string
	 * @since  1.0
	 */
	protected $url = '';

	/**
	 * Path of plugin directory.
	 *
	 * @var    string
	 * @since  1.0
	 */
	protected $path = '';

	/**
	 * Plugin basename.
	 *
	 * @var    string
	 * @since  1.0
	 */
	protected $basename = '';

	/**
	 * Detailed activation error messages.
	 *
	 * @var    array
	 * @since  1.0
	 */
	protected $activation_errors = array();

	/**
	 * Singleton instance of plugin.
	 *
	 * @var    Vexsoluciones_Woocommerce_Skydropx
	 * @since  1.0
	 */
	protected static $single_instance = null;

	/**
	 * Creates or returns an instance of this class.
	 *
	 * @since   1.0
	 * @return  Vexsoluciones_Woocommerce_Skydropx A single instance of this class.
	 */
        
        protected $plugin_class;
        
	public static function get_instance() {
		if ( null === self::$single_instance ) {
			self::$single_instance = new self();
		}

		return self::$single_instance;
	}

	/**
	 * Sets up our plugin.
	 *
	 * @since  1.0
	 */
	protected function __construct() {
		$this->basename = plugin_basename( __FILE__ );
		$this->url      = plugin_dir_url( __FILE__ );
		$this->path     = plugin_dir_path( __FILE__ );
               
	}

	/**
	 * Attach other plugin classes to the base plugin class.
	 *
	 * @since  1.0
	 */
	public function plugin_classes() {
            $this->plugin_class = [];
            $this->plugin_class[VexSolucionesSkydropxShippings::class] = VexSolucionesSkydropxShippings::getInstance();
            $this->plugin_class[VexSolucionesSkydropxSettings::class] = VexSolucionesSkydropxSettings::getInstance();
	} // END OF PLUGIN CLASSES FUNCTION
        
        public function getInstanceOf($className) {
            switch($className) {
                case VexSolucionesSkydropxShippings::class:
                case VexSolucionesSkydropxSettings::class:
                case VexSolucionesSkydropxLicenseManager::class:
                    return $this->plugin_class[$className];
            }
            return false;
        }
        
        public function getLicenseManager() {
            return $this->getInstanceOf(VexSolucionesSkydropxLicenseManager::class);
        }
        
	/**
	 * @return  VexSolucionesSkydropxSettings
	 */
        public function getSettings($author=false) {
            if(!$author)
                return $this->getInstanceOf(VexSolucionesSkydropxSettings::class);
            return new VexSolucionesSkydropxSettings($author);
        }

	/**
	 * Add hooks and filters.
	 * Priority needs to be
	 * < 10 for CPT_Core,
	 * < 5 for Taxonomy_Core,
	 * and 0 for Widgets because widgets_init runs at init priority 1.
	 *
	 * @since  1.0
	 */
	public function hooks() {
            add_action( 'init', array( $this, 'init' ), 0 );
          /*add_action("admin_init", function() {
                if(!is_plugin_active( 'vexsoluciones-peru-ubigeo/vexsoluciones-peru-ubigeo.php')) {
                    add_action( 'admin_notices', function() {
                        $class = 'notice notice-error';
                        $message = __( 'Este plugin requiere a Vexsoluciones Peru Ubigeo para funcionar correctamente', self::TEXT_DOMAIN );
                        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) ); 
                    });
                    $this->deactivate_me();
                }
            });*/
            $this->executeControllerActions(VexsolucionesSkydropxCheckoutController::getInstance());
            $this->executeControllerActions(VexSolucionesSkydropxOrdersController::getInstance());
            add_filter('woocommerce_get_order_item_totals', function($total_rows, $order) {
                Vexsoluciones_Woocommerce_Skydropx::doIfOrderIsSkydropx($order, function() use($order, &$total_rows) { 
                    $shippingType =get_post_meta($order->get_id(), 'skydropx_paqueteria', true);
                   
                    $skydropx_shipping_type = [
                       'label' => 'Tipo de envío:',
                       'value'   => $shippingType
                    ];
                    $skydropx_datetime = null;
                  /*  if($shippingType == "Express") {
                        $time = get_post_meta($order->get_id(), 'skydropx_shipping_datetime', true);
                        $datetime = new DateTime($time);
                        $skydropx_datetime = [
                           //'label' => 'Hora y fecha de recojo:',
                           'value'   => $datetime->format('d/m/Y H:i:s')
                        ];
                    }*/
                    // rearrange rows
                    $shipping = $total_rows['shipping'];
                    $cart_subtotal = $total_rows['cart_subtotal'];
                    $order_total = $total_rows['order_total'];
                    unset($total_rows['shipping']);
                    unset($total_rows['cart_subtotal']);
                    unset($total_rows['order_total']);
                    $total_rows['shipping'] = $shipping;
                    $total_rows['skydropx_shipping_type'] = $skydropx_shipping_type;
                    if($skydropx_datetime != null)
                        //$total_rows['skydropx_datetime'] = $skydropx_datetime;
                    $total_rows['cart_subtotal'] = $cart_subtotal;
                    $total_rows['order_total'] = $order_total;
                    // ...
                });
                return $total_rows;
            }, 10, 2);
	}

	/**
	 * Activate the plugin.
	 *
	 * @since  1.0
	 */
	public function _activate() {
		// Bail early if requirements aren't met.
		if ( ! $this->check_requirements() ) {
			return;
                } 

                 
		// Make sure any rewrite functionality has been loaded.
                flush_rewrite_rules();

	}

	/**
	 * Deactivate the plugin.
	 * Uninstall routines should be in uninstall.php.
	 *
	 * @since  1.0
	 */
	public function _deactivate() {
            // Add deactivation cleanup functionality here.
            
	}

	/**
	 * Init hooks
	 *
	 * @since  1.0
	 */
	public function init() {

		// Bail early if requirements aren't met.
		if ( ! $this->check_requirements() ) {
			return;
		}
              
		// Load translated strings for plugin.
		load_plugin_textdomain( self::TEXT_DOMAIN, false, dirname( $this->basename ) . '/languages/' );

		// Initialize plugin classes.
                $this->plugin_classes();
	}

	/**
	 * Check if the plugin meets requirements and
	 * disable it if they are not present.
	 *
	 * @since  1.0
	 *
	 * @return boolean True if requirements met, false if not.
	 */
	public function check_requirements() {

		// Bail early if plugin meets requirements.
		if ( $this->meets_requirements() ) {
			return true;
		}

		// Add a dashboard notice.
		add_action( 'all_admin_notices', array( $this, 'requirements_not_met_notice' ) );

		// Deactivate our plugin.
		add_action( 'admin_init', array( $this, 'deactivate_me' ) );

		// Didn't meet the requirements.
		return false;
	}

	/**
	 * Deactivates this plugin, hook this function on admin_init.
	 *
	 * @since  1.0
	 */
	public function deactivate_me() {

		// We do a check for deactivate_plugins before calling it, to protect
		// any developers from accidentally calling it too early and breaking things.
		if ( function_exists( 'deactivate_plugins' ) ) {
			deactivate_plugins( $this->basename );
		}
	}

	/**
	 * Check that all plugin requirements are met.
	 *
	 * @since  1.0
	 *
	 * @return boolean True if requirements are met.
	 */
	public function meets_requirements() {

		// Do checks for required classes / functions or similar.
		// Add detailed messages to $this->activation_errors array.
		return true;
	}

	/**
	 * Adds a notice to the dashboard if the plugin requirements are not met.
	 *
	 * @since  1.0
	 */
	public function requirements_not_met_notice() {

		// Compile default message.
		$default_message = sprintf( __( 'Woocommerce Skydropx is missing requirements and has been <a href="%s">deactivated</a>. Please make sure all requirements are available.', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ), admin_url( 'plugins.php' ) );

		// Default details to null.
		$details = null;

		// Add details if any exist.
		if ( $this->activation_errors && is_array( $this->activation_errors ) ) {
			$details = '<small>' . implode( '</small><br /><small>', $this->activation_errors ) . '</small>';
		}

		// Output errors.
		?>
		<div id="message" class="error">
			<p><?php echo wp_kses_post( $default_message ); ?></p>
			<?php echo wp_kses_post( $details ); ?>
		</div>
		<?php
	}

	/**
	 * Magic getter for our object.
	 *
	 * @since  1.0
	 *
	 * @param  string $field Field to get.
	 * @throws Exception     Throws an exception if the field is invalid.
	 * @return mixed         Value of the field.
	 */
	public function __get( $field ) {
		switch ( $field ) {
			case 'version':
				return self::VERSION;
			case 'basename':
			case 'url':
			case 'path':
				return $this->$field;
			default:
				throw new Exception( 'Invalid ' . __CLASS__ . ' property: ' . $field );
		}
	}
        
        public static function plugin_url() {
            return content_url() . "/plugins/SkydropX";
        }
        
        /* get only orders for subscriptions sortered by date */
        public static function getOrders($filters=[], $statuses=["wc-pending", "wc-processing", "wc-cancelled", "wc-on-hold", "wc-completed", "wc-refunded", "wc-failed"], $author=false) {
            $filters = wp_parse_args($filters, [
                // "suppress_filters" => false,
                'post_type' => 'shop_order',
                "posts_per_page" => -1,
                'orderby'   => 'post_date',
                'order' => 'DESC',
                'post_status' => $statuses
                /* 'meta_query' => [
                   'relation' => 'AND',
                   [
                     'key' => '_payment_method',
                     'value' => apply_filters("oneclick_gateways_ids", [call_user_func(get_called_class() . "::getGatewayId")])
                   ]
                ], */
            ]);
            $orders = get_posts($filters);
            $arr = [];
            foreach($orders as $postOrder) {
                $order = wc_get_order($postOrder->ID);
                self::doIfOrderIsSkydropx($order, function() use($order, &$arr) {
                    if(metadata_exists('post', $order->get_id(), VexSolucionesSkydropxShippingMethod::SHIPPING_STATE) || metadata_exists('post', $order->get_id(), 'skydropx_id'))
                        $arr[] = $order;
                });
            }
            return apply_filters('skydropx_orders', $arr);
        }
        
        public static function doIfOrderIsSkydropx($order, $callback) {
            if($order instanceof WC_Order) {
                $isSkydropx = false;
                foreach( $order->get_items( 'shipping' ) as $item_id => $shipping_item_obj ) {
                    $shipping_item_data = $shipping_item_obj->get_data();
                    if($shipping_item_data["name"] == __("Skydropx", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN)) {
                        $isSkydropx = true;
                        break;
                    }
                }
                if($isSkydropx) 
                    $callback();
            }
        }
        
        private function executeControllerActions($controller) {
            $methods = get_class_methods($controller);
            foreach($methods as $method) {
                if(strpos($method, 'Action') !== false)
                    call_user_func([$controller, $method]);
            }
        }
        
}

/**
 * Grab the Woocommerce_Skydropx_Courier object and return it.
 * Wrapper for Woocommerce_Skydropx_Courier::get_instance().
 *
 * @since  1.0
 * @return Vexsoluciones_Woocommerce_Skydropx  Singleton instance of plugin class.
 */
function Vexsoluciones_Woocommerce_Skydropx() {
	return Vexsoluciones_Woocommerce_Skydropx::get_instance();
}

// Kick it off.
add_action( 'plugins_loaded', array( Vexsoluciones_Woocommerce_Skydropx(), 'hooks' ) );
// Activation and deactivation.
register_activation_hook( __FILE__, array( Vexsoluciones_Woocommerce_Skydropx(), '_activate' ) );
register_deactivation_hook( __FILE__, array( Vexsoluciones_Woocommerce_Skydropx(), '_deactivate' ) );

add_action( 'wp_enqueue_scripts', 'googlesript' );
function googlesript() {
	   
		if(get_option('skydropx_servicios_google')=='enabled')
		{
			if(is_checkout()) {
	   $apig=get_option('skydropx_google_api_key');
		/* checkout behavior */
		   wp_enqueue_style("skydropx-checkout", Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/css/checkout.css');
			   wp_enqueue_script('google-maps', 'https://maps.googleapis.com/maps/api/js?v=3&key='.$apig.'&sensor=false&libraries=places');
		   wp_enqueue_script('skydropx', Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/js/checkout.js', array('jquery'), Vexsoluciones_Woocommerce_Skydropx::VERSION, true);
		}
		}
		   }
		   add_action( 'wp_enqueue_scripts', 'utilsjs' );
function utilsjs() {
	if(is_checkout()) {
		wp_enqueue_script('skydropx_util_refresh', Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/js/utils.js', array('jquery'), Vexsoluciones_Woocommerce_Skydropx::VERSION, true);
	}

}
         
        
			add_action( 'woocommerce_view_order', 'misha_view_order_and_thankyou_page', 20 );

			function misha_view_order_and_thankyou_page( $order_id ){ 
				$is_track = get_post_meta( $order_id, 'skydropx_id', true ); 
			
				?>
				<h2>Información de Envío - Skydropx</h2>
				<table class="woocommerce-table shop_table gift_info">
					<tbody>
						<tr>
							<th>Estatus</th>
							
							<td><?php 
							$skydropxStatus= get_post_meta( $order_id, 'skydropx_status', true );
							 if($skydropxStatus!="error"):
                                switch($skydropxStatus)
                                {
                                    case "fullfillmert":
                                        $status="<button style='background:#03a9f4; border-color:#03a9f4; font-weight:bold;color: #fff;'>ORDEN CREADA</button>";
                                        break;
                                    case "PICKED_UP":
                                    $status="<button style='background:orange;border-color:orange; font-weight:bold;color: #fff'>RECOGIDA</button>";
                                    break;
                                    case "IN_TRANSIT":
                                    $status="<button style='background:yellow;border-color:yellow; font-weight:bold;color: #fff'>EN TRÁNSITO</button>";
                                    break;
                                    case "DELIVERED":
                                    $status="<button style='background:green;border-color: green; font-weight:bold;color: #fff'>ENTREGADA</button>";
                                    break;
                                    case "CANCELLED":
                                    $status="<button style='background:red;border-color:red; font-weight:bold;color: #fff'>CANCELADA</button>";
                                    break;
                                   
                                   
                                }
                            else:
                                $status="<button style='background:red;border-color:red; font-weight:bold;color: #fff'>ERROR</button>";
                            endif;
                                echo $status; ?>
							</td>
						</tr>
					 <?php 	if( $is_track ) : ?>
						<tr>
						<?php
							if($skydropxStatus=="error")
                        {
                            if(get_post_meta($order_id,'skydropx_referencia', true)!=false)
                            {
                            $skydropxCode=get_post_meta($order_id, 'skydropx_nota', true);
                            $nota=get_post_meta($order_id, 'skydropx_referencia', true);
                            }
                            else
                            {
                                $skydropxCode=get_post_meta($order_id, 'skydropx_error', true);
                                $nota=get_post_meta($order_id, 'skydropx_error_code', true);

                            }
                        }
                        else
                        {
                            $skydropxCode = get_post_meta($order_id, 'skydropx_tracking', true);
							$nota="Exitoso";
                        }
?>
							<th>Informacion:</th>
							<td><?php echo $skydropxCode;?></td>
						</tr>
						<tr>
							<th>Tracking</th>
							<td> 
						<?php echo $nota;?>
							</td>
						</tr>
						
						<?php endif; ?>
					</tbody>
				</table>
			<?php }
			//email for user
			add_action( 'woocommerce_email_after_order_table', 'vexsoluciones_skydropx_email', 20, 4 );
			
			function vexsoluciones_skydropx_email( $order, $sent_to_admin, $plain_text, $email ) { 
				$skydropx_stat = get_post_meta($order->get_id(), "skydropx_status", true); 
				$tracking = get_post_meta($order->get_id(), "skydropx_tracking", true);

			$isSended = (!empty($skydropx_guia));
			if(!empty($isSended)):
			   if ( $email->id == 'customer_completed_order' ) {
				  echo '<h2 class="email-upsell-title">Información de envío:</h2>
				  <table class="woocommerce-table shop_table gift_info">
				  <tbody>
					  <tr>
						  <th style="color:#636363;">Status:</th>
							<td><b>'.$skydropx_stat.'</b></td>
						  
					  </tr>
					  <tr>
					  <th style="color:#636363;">Nro de traking:</th>
						<td><b>'.$tracking.'</b></td>
					  
				  </tr> 
				  ';
			   }
			endif;
			}