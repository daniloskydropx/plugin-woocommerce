<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */ 
switch(array_key_exists("action", $_POST) && $_POST["action"]):
    case "sendManually":
        $order = wc_get_order(intval($_POST["order_id"]));
        $type = __("Correcto", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN);
        $msg = __("Se ha realizado de nuevo el envio", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN);
        $clase="notice-success";
        if(!$order) {
            $type = __("Info", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN);
            $msg = __("No se ha logrado obtener la informacion de la orden", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN);
        } else {
            try {
                $settings = VexSolucionesSkydropxShippingMethod::getSettingsForOrder($order);
                VexsolucionesSkydropxCheckout::sendSkydropxShipping($order, $settings);
                $wooState = get_post_meta($order->get_id(), VexSolucionesSkydropxShippingMethod::SHIPPING_STATE, true);
                if(!empty($wooState)) {
                    $type = "Información";
                    $msg = $wooState;
                     $clase="notice-information";
                }
            } catch(Exception $e) {
                $type = __("Info", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN);
                $msg = $e->getMessage();
            }
        }
        ?>
        <div class="notice <?php echo $clase; ?>"><p><strong><?php echo $type; ?>:</strong> <?php echo $msg; ?>.</p></div>
        <?php
    default: ?>
        <center><h2 class="section-title"><?php echo __( 'Ordenes Realizadas con Skydropx.', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></h2></center><br>
        <table class="table display" style="margin-top: 10px;" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th style="text-align: center; vertical-align: middle;">
                        <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                        <?php echo __("Orden", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                    </th>
                    <th style="text-align: center; vertical-align: middle;">
                        <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                        <?php echo __("Costo Envío", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                    </th>
                    <th style="text-align: center; vertical-align: middle;">
                        <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                        <?php echo __("Fecha", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                    </th>
                    <th style="text-align: center; vertical-align: middle;">
                        <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                        <?php echo __("Estado", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                    </th>
                    <th style="text-align: center; vertical-align: middle;">
                        <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                        <?php echo __("Método de pago", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                    </th>
                    <th style="text-align: center; vertical-align: middle;">
                        <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                        <?php echo __("Paquetería", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                    </th>

                    <th style="text-align: center; vertical-align: middle;">
                        <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                        <?php echo __("Shipping Id", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                    </th>
                    <th style="text-align: center; vertical-align: middle;">
                        <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                        <?php echo __("Skydropx Info", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                    </th>
                    <th style="text-align: center; vertical-align: middle;">
                        <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                        <?php echo __("Shipping Status", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                    </th>
                    <th style="text-align: center; vertical-align: middle;">
                        <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                        <?php echo __("Tracking", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                    </th>
                    <?php
                    if(is_admin()): ?>
                        <th style="text-align: center; vertical-align: middle;">
                            <svg width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M736 1440q0 12-10 24l-319 319q-10 9-23 9-12 0-23-9l-320-320q-15-16-7-35 8-20 30-20h192v-1376q0-14 9-23t23-9h192q14 0 23 9t9 23v1376h192q14 0 23 9t9 23zm1056 128v192q0 14-9 23t-23 9h-832q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h832q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-640q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h640q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-448q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h448q14 0 23 9t9 23zm-192-512v192q0 14-9 23t-23 9h-256q-14 0-23-9t-9-23v-192q0-14 9-23t23-9h256q14 0 23 9t9 23z"/></svg>
                            <?php echo __("Envío Manual", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>
                        </th>
                    <?php
                    endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php
                $orders = Vexsoluciones_Woocommerce_Skydropx::getOrders($filters);
                if(!count($orders)): ?>
                    <tr><td colspan="13"><center><h1><?php echo __("No hay ordenes en este momento.", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></h1></center></td></tr>
                <?php
                else: 
                    foreach($orders as $order):
                        $wpuser = get_user_by("ID", $order->get_user_id());
                        $paymentMethod = get_post_meta($order->get_id(), "_payment_method", true);
                        //$recogida = get_post_meta($order->get_id(), "skydropx_shipping_datetime", true);
                        //$recogida = empty($recogida) ? __('Solo aplica para tipo de envío Express.', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN) : $recogida;
                        $wooState = get_post_meta($order->get_id(), VexSolucionesSkydropxShippingMethod::SHIPPING_STATE, true);
                        $trackingLink = get_post_meta($order->get_id(), 'skydropx_trackingprovider', true);
                        $skydropxStatus = get_post_meta($order->get_id(), 'skydropx_status', true);
                        if($skydropxStatus=="error")
                        {
                            if(get_post_meta($order->get_id(),'skydropx_referencia', true)!=false)
                            {
                            $skydropxCode=get_post_meta($order->get_id(), 'skydropx_nota', true);
                            $nota=get_post_meta($order->get_id(), 'skydropx_referencia', true);
                            }
                            else
                            {
                                $skydropxCode=get_post_meta($order->get_id(), 'skydropx_error', true);
                                $nota=get_post_meta($order->get_id(), 'skydropx_error_code', true);

                            }
                        }
                        else
                        {
                            $skydropxCode = get_post_meta($order->get_id(), 'skydropx_tracking', true);
                        }
                        
                        $skydropxId = get_post_meta($order->get_id(), 'skydropx_id', true);
                        $isSended = !empty($skydropxStatus) && !empty($skydropxCode) && !empty($skydropxId);
                        $shippingType = get_post_meta($order->get_id(), 'skydropx_paqueteria', true);?>
                        <tr>
                            <td style="text-align: center; vertical-align: middle;">
                                <?php
                                $pattern = is_admin() ? '<a href="'.admin_url() . "post.php?post={$order->get_id()}&action=edit".'">%s</a>' : "%s";
                                $link = printf($pattern, "{$order->get_id()}"); ?>
                            </td>
                            <td style="text-align: center; vertical-align: middle;"><?php echo get_woocommerce_currency_symbol() . " " . $order->get_total_shipping(); ?></td>
                            <td style="text-align: center; vertical-align: middle;"><?php echo $order->get_date_created()->date("Y-m-d H:i:s"); ?></td>
                            <td style="text-align: center; vertical-align: middle;"><?php echo $order->get_status(); ?></td>
                            <td style="text-align: center; vertical-align: middle;"><?php echo $paymentMethod; ?></td>
                            <td style="text-align: center; vertical-align: middle;"><?php echo $shippingType; ?></td>
                           <!-- <td style="text-align: center; vertical-align: middle;"><?php echo $recogida; ?></td>-->
                            <?php 
                            if($isSended): ?>
                                <td style="text-align: center; vertical-align: middle;"><?php echo $skydropxId ?></td>
                                <td style="text-align: center; vertical-align: middle; <?php if($skydropxStatus!="error"){echo "display:none;";} ?>"><?php echo $skydropxCode ?></td>
                                <td style="text-align: center; vertical-align: middle;" <?php if($skydropxStatus!="error"){echo "colspan=2";} ?>><?php
                               if($skydropxStatus!="error"):
                                switch($skydropxStatus)
                                {
                                    case "fullfillmert":
                                        $status="<button style='background:#03a9f4; border-color:#03a9f4; font-weight:bold;color: #fff;'>ORDEN CREADA</button>";
                                        break;
                                    case "PICKED_UP":
                                    $status="<button style='background:orange;border-color:orange; font-weight:bold;color: #fff'>RECOGIDA</button>";
                                    break;
                                    case "IN_TRANSIT":
                                    $status="<button style='background:yellow;border-color:yellow; font-weight:bold;color: #fff'>EN TRÁNSITO</button>";
                                    break;
                                    case "DELIVERED":
                                    $status="<button style='background:green;border-color: green; font-weight:bold;color: #fff'>ENTREGADA</button>";
                                    break;
                                    case "CANCELLED":
                                    $status="<button style='background:red;border-color:red; font-weight:bold;color: #fff'>CANCELADA</button>";
                                    break;
                                   
                                   
                                }
                            else:
                                $status="<button style='background:red;border-color:red; font-weight:bold;color: #fff'>ERROR</button>";
                            endif;
                                echo $status; ?></td>
                            <?php
                            endif; ?>
                            <td style="text-align: center; vertical-align: middle;" <?php echo !$isSended ? "colspan=4" : "";  ?>>
                                <?php
                                if($isSended)
                                {
                                    if($skydropxStatus=="error")
                                    {
                                        echo $nota;
                                    }
                                    else
                                    {
                                        echo '#'.$skydropxCode.'<br>';
                                        ?>
                                        
                                        <a href="#" onclick="window.open('<?= $trackingLink ?>', '', 'width=640,height=480')"><?php echo __("Ir a tracking", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></a><br>
                                        <p><a href="<?php echo get_post_meta($order->get_id(), 'skydropx_trackingurl', true); ?>" target="_blank">Ver etiqueta</a></p>
                                        <?php
                                    }
                                }

                                else
                                {

                                if(is_admin()): ?><button type="button"><?php endif; echo __($wooState, Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); if(is_admin()): ?></button><?php endif; ?>
                                <?php
                                } 
                                ?>
                            </td>
                            <?php
                            if(is_admin()): ?>
                                <td style="text-align: center; vertical-align: middle;">
                                    <?php
                                    if($skydropxId != 1): ?>
                                        <form method="POST">
                                            <input type="hidden" name="action" value="sendManually">
                                            <input type="hidden" name="order_id" id="order_id" value="<?php echo $order->get_id(); ?>">
                                            <button type="submit"><svg width="25" height="25" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1664 896q0 156-61 298t-164 245-245 164-298 61q-172 0-327-72.5t-264-204.5q-7-10-6.5-22.5t8.5-20.5l137-138q10-9 25-9 16 2 23 12 73 95 179 147t225 52q104 0 198.5-40.5t163.5-109.5 109.5-163.5 40.5-198.5-40.5-198.5-109.5-163.5-163.5-109.5-198.5-40.5q-98 0-188 35.5t-160 101.5l137 138q31 30 14 69-17 40-59 40h-448q-26 0-45-19t-19-45v-448q0-42 40-59 39-17 69 14l130 129q107-101 244.5-156.5t284.5-55.5q156 0 298 61t245 164 164 245 61 298z"/></svg></button>
                                        </form>
                                    <?php
                                    else: ?>
                                        <svg width="25" height="25" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1299 813l-422 422q-19 19-45 19t-45-19l-294-294q-19-19-19-45t19-45l102-102q19-19 45-19t45 19l147 147 275-275q19-19 45-19t45 19l102 102q19 19 19 45t-19 45zm141 83q0-148-73-273t-198-198-273-73-273 73-198 198-73 273 73 273 198 198 273 73 273-73 198-198 73-273zm224 0q0 209-103 385.5t-279.5 279.5-385.5 103-385.5-103-279.5-279.5-103-385.5 103-385.5 279.5-279.5 385.5-103 385.5 103 279.5 279.5 103 385.5z"/></svg>
                                    <?php
                                    endif; ?>
                                </td>
                            <?php
                            endif; ?>
                        </tr>
                    <?php
                    endforeach;
                endif; ?>
            </tbody>
        </table>

   <!--Modal-->
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('.table').DataTable();
            });
        </script>
        <?php
        break;
endswitch; ?>

