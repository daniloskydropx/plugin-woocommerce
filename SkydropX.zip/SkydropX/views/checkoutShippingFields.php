<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2021 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

defined('ABSPATH') || exit; 
?>
<input id="apioculta" type="hidden" value="<?php echo get_option('peru_ubigeos_google_api_key')?>">
<script type="text/javascript">
            console.log('<?php echo get_option('peru_ubigeos_google_api_key')?>');
        </script>
<?php
if($method->id != VexSolucionesSkydropxShippingMethod::ID)
    return;
$chosen_methods = WC()->session->get( 'chosen_shipping_methods' );
$chosen_shipping = $chosen_methods[$index]; 
if($chosen_shipping != VexSolucionesSkydropxShippingMethod::ID)
    return;
$package = WC()->cart->get_shipping_packages()[$index];
$check = array_key_exists(VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE . "_{$index}", $data) ? $data[VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE . "_{$index}"] : 0; ?>

</td></tr> <!-- Fix Woocommerce -->

<tr class="woocommerce-shipping-totals shipping">
    <th>
        <h5 style="color: #737373; display: inline; font-size: 14px; font-weight: bold;"><?php echo __("Skydropx / Seleccione tipo de envío", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?></h5>
    </th>
    <td>
        <p style="padding-left: 15px;">
        <?php 
//obtener paqueteria
$data = [];
        if(array_key_exists("post_data", $_POST))
            parse_str($_POST["post_data"], $data);
        $zip=$data['billing_postcode'];
   
     if(!empty($zip)) {
            $wharehouse = VexSolucionesWharehouse::getClosestWharehouse($settings->getWharehouses(), $lat, $lgt);
            // $distance = VexSolucionesUtils::getDistanceFromLatLonInKm($wharehouse->lat, $wharehouse->lgt, $lat, $lgt);
            //$shippingType = intval($shippingType);
     
           // $returnToOrigin = $settings->returnToOrigin() == 'yes' ? 'true' : 'false';
             global $woocommerce;
                foreach(WC()->cart->get_cart() as $cart_item) { 
        // Get an instance of the WC_Product object and cart quantity
        $product = $cart_item['data'];
        $qty= $cart_item['quantity'];

        // Get product dimensions  
        $length = $product->get_length();
        $width  = $product->get_width();
        $height = $product->get_height();
       $weight = $product->get_weight();

        // Calculations a item level
        $totallength1=$length*$qty;
        $totalwidth1=$width*$qty;
        $totalheight1=$height*$qty;
       $totalweight1=$weight*$qty;
       $totallength+=$totallength1;
       $totalwidth+=$totalwidth1;
       $totalheight+=$totalheight1;
       $totalweight+=$totalweight1;

    } 

$key=$settings->getSkydropxApiKey();
$url = $settings->getEnvironmentMode() === 'enabled' ? 'https://sb-ecommerce-service.skydropx.com' : 'https://ecommerce-service.skydropx.com';
$curl = curl_init();
curl_setopt_array($curl, array(
CURLOPT_URL => "{$url}/v1/rates",
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => "",
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 30,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => "POST",
CURLOPT_POSTFIELDS => "{\r\n  \"zip_from\": \"{$wharehouse->zip}\",\r\n  \"zip_to\": \"{$zip}\",\r\n  \"parcel\": {\r\n    \"weight\": {$totalweight},\r\n    \"height\": {$totalheight},\r\n    \"width\": {$totalwidth},\r\n    \"length\": {$totallength}\r\n  }\r\n}",
CURLOPT_HTTPHEADER => array(
    "authorization: token=".$key."",
    "Content-Type: application/json",
    "Accept: application/json"
),
));

$response = curl_exec($curl);
curl_close($curl);
    $response = json_decode($response, true);
      if($response) {
        if($response['success']==true)
        {
        $dato=$response['data'];
       $long=count($dato);
        for ($i = 0; $i < $long; ++$i){
      //echo $response[$i]['provider'].' ('.$response[$i]['service_level_name'].'):'.$response[$i]['total_pricing'].' '.$response[$i]['service_level_code'].'<br>';
      $sameDayCost = VexSolucionesSkydropxShippingMethod::getCostSkydropx($package, $i);
      if($sameDayCost != 0): ?>
    <label id="tipoenvio" style="display: block; padding: 5px 0; font-weight: bold;">
                <input class="typeshipping" type="radio" name="<?php echo VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE; ?>_<?php echo $index; ?>" id="skydropx_regular_<?php echo $index; ?>" value="<?php echo $i;?>" style="margin-right: 3px;" <?php echo $check == $i ? 'checked' : ''; ?>>
                <?php 
                echo $dato[$i]['provider']." <span style='font-size: 11px; font-weight: normal;'>({$dato[$i]['service_level_name']} - {$dato[$i]['days']}días)</span><br>";
                echo get_woocommerce_currency_symbol().$sameDayCost; ?>
            </label>
            <input type="hidden" name="nameenvio<?php echo $i;?>" value="<?php echo $dato[$i]['provider'].' ('.$dato[$i]['service_level_name'].')'?>">
            <input type="hidden" name="provider<?php echo $i;?>" value="<?php echo $dato[$i]['provider']?>">
            <input type="hidden" name="level_code<?php echo $i;?>" value="<?php echo $dato[$i]['service_level_code']?>">
        
        <?php
        endif;
        }
    }
    else
    {
        wc_add_notice( 'Ha ocurrido un error '.$response['message'].'', 'error' );
    }
    }
}
               ?>
              
        </p>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('input[name="<?php echo VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE; ?>_<?php echo $index; ?>"]').on("change", function() {
                    $(document.body).trigger("update_checkout");
                });
                if($("#skydropx_programatically_<?php echo $index; ?>").is(':checked')) 
                    $('#skydropx_shipping_datetime_container_<?php echo $index; ?>').show();
                 

                /* Date Time Pickers */
                // var availableDaysAndTimes = JSON.parse(`<?php echo json_encode($settings->getTimesShedules()); ?>`);
                <?php
                switch($check):
                    case 2: ?>
                        var availableDaysAndTimes = JSON.parse(`{"days":{"monday":{"since":"09:00","until":"21:00"},"tuesday":{"since":"09:00","until":"21:00"},"wednesday":{"since":"09:00","until":"21:00"},"thursday":{"since":"09:00","until":"21:00"},"friday":{"since":"09:00","until":"21:00"},"saturday":{"since":"09:00","until":"13:00"}}}`);
                        <?php
                        break;
                    case 1: ?>
                        var availableDaysAndTimes = JSON.parse(`{"days":{"monday":{"since":"09:00","until":"18:00"},"tuesday":{"since":"09:00","until":"18:00"},"wednesday":{"since":"09:00","until":"18:00"},"thursday":{"since":"09:00","until":"18:00"},"friday":{"since":"09:00","until":"18:00"},"saturday":{"since":"09:00","until":"14:00"}}}`);
                        <?php
                        break;
                    default: ?>
                        var availableDaysAndTimes = JSON.parse(`{"days":{"monday":{"since":"09:00","until":"21:00"},"tuesday":{"since":"09:00","until":"21:00"},"wednesday":{"since":"09:00","until":"21:00"},"thursday":{"since":"09:00","until":"21:00"},"friday":{"since":"09:00","until":"21:00"},"saturday":{"since":"09:00","until":"18:00"}}}`);
                        <?php
                        break;
                endswitch; ?>
                var disabledDates = JSON.parse(`<?php echo json_encode($settings->getHolidaysSheduleOnlyTimes()); ?>`);
                if(!disabledDates.length)
                    disabledDates = [];
                var weekDaysDisabled = JSON.parse(`<?php echo json_encode($settings->getDisabledWeekDays()); ?>`);
                if(!weekDaysDisabled.length)
                    weekDaysDisabled = [];
                var lastDateTime = $(dateTimeFieldSelector).val();
                var initialsItems = Array();
                jQuery.datetimepicker.setLocale('es');
                var dateTimeFieldSelector = "#skydropx_shipping_datetime_<?php echo $index; ?>";
                $(dateTimeFieldSelector).datetimepicker({
                    timepicker: false,
                   format:'d/m/y',
                    //timeFormat: 'HH:mm',
                    minDate: new Date(),
                    /* minTime: new Date(),*/ 
                    disabledDates: /* disabledDates */ [],
                    disabledWeekDays: /* weekDaysDisabled */ [],
                    //formatDate:'Y-m-d',
                    onClose: function() {
                        if(lastDateTime !== $(dateTimeFieldSelector).val()) {
                            lastDateTime = $(dateTimeFieldSelector).val();
                        }
                    },
                    onGenerate:function( ct ) {
                        /* disable first 2 avalidables dates when lima is selected */
                        var billingOrShipping = !jQuery("#ship-to-different-address-checkbox").is(":checked") ? "billing" : "shipping";
                        var departament = jQuery("#" + billingOrShipping + "_state");
                        var vaca = 0;
                        $(this).find('.xdsoft_date').each(function() {
                            var theDate = $(this);
                            if(!theDate.hasClass("xdsoft_disabled")) {
                                if(departament.val() === "LIM") {
                                    var itemDate = theDate.attr("data-date")+"-"+theDate.attr("data-month")+"-"+theDate.attr("data-year");
                                    if(!(vaca < 2))
                                        return false;
                                    if(initialsItems.indexOf(itemDate) !== -1)
                                        $(this).addClass("xdsoft_disabled");
                                    vaca++;
                                    if(initialsItems.length < 2)
                                        initialsItems.push(itemDate);
                                }
                            }
                        });
                        /* disable unvailable times */
                        var days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
                        var selectedDay = days[ct.getDay()];
                        var availableTimes = availableDaysAndTimes.days[selectedDay];
                        if(typeof availableTimes !== 'undefined') {
                            var since = parseInt(availableTimes.since.split(":")[0]), until = parseInt(availableTimes.until.split(":")[0]);
                            $(this).find('.xdsoft_time').each(function() {
                                var itemHour = parseInt($(this).attr("data-hour"));
                                if(itemHour < since || itemHour > until)
                                    $(this).addClass("xdsoft_disabled");
                            });
                        }
                    }
                });
                /* hide skydropx price */
                $('.shipping_method').each(function() {
                    if($(this).attr('id').includes('_vex_soluciones_skydropx')) {
                        $(this).next().find('.woocommerce-Price-amount').hide();
                    }
                });
                $(document).trigger('update-checkout');
            });
        </script>
    </td>
</tr>
