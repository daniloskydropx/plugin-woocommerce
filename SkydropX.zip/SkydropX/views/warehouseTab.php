<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */ ?>
<table class="form-table">
    <tbody>
       <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::PROVINCE; ?>"><?php echo __( 'Estado', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::PROVINCE; ?>[]" id="<?php echo VexSolucionesWharehouse::PROVINCE; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->province : ""; ?>">
            </td>
        </tr>
           <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::DISTRICT; ?>"><?php echo __( 'Ciudad', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::DISTRICT; ?>[]" id="<?php echo VexSolucionesWharehouse::DISTRICT; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->district : ""; ?>">
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::DIR1; ?>"><?php echo __( 'Dirección 1', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::DIR1; ?>[]" id="<?php echo VexSolucionesWharehouse::DIR1; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->dir1 : ""; ?>">
            </td>
        </tr>
        <tr>
        <tr>
 <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::DIR2; ?>"><?php echo __( 'Dirección 2', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::DIR2; ?>[]" id="<?php echo VexSolucionesWharehouse::DIR2; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->dir2 : ""; ?>">
            </td>
        </tr>

            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::ZIP; ?>"><?php echo __( 'Código Zip', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::ZIP; ?>[]" id="<?php echo VexSolucionesWharehouse::ZIP; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->zip : ""; ?>">
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::REFERENCE; ?>"><?php echo __( 'Referencia del comercio', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::REFERENCE; ?>[]" id="<?php echo VexSolucionesWharehouse::REFERENCE; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->reference : ""; ?>">
            </td>
        </tr>
        <tr>
                    <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::COMPANY; ?>"><?php echo __( 'Nombre de la empresa', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" id="company" name="<?php echo VexSolucionesWharehouse::COMPANY; ?>[]" id="<?php echo VexSolucionesWharehouse::COMPANY; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->company : ""; ?>">
                <input type="hidden" id="compania" name="compania">
            </td>
        </tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::CONTACT_NAME; ?>"><?php echo __( 'Nombre del contacto', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::CONTACT_NAME; ?>[]" id="<?php echo VexSolucionesWharehouse::CONTACT_NAME; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->contactName : ""; ?>">
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::EMAIL; ?>"><?php echo __( 'Email', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::EMAIL; ?>[]" id="<?php echo VexSolucionesWharehouse::EMAIL; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->email : ""; ?>">
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="<?php echo VexSolucionesWharehouse::CONTACT_PHONE; ?>"><?php echo __( 'Teléfono del contacto', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); ?></label></th>
            <td>
                <input type="text" name="<?php echo VexSolucionesWharehouse::CONTACT_PHONE; ?>[]" id="<?php echo VexSolucionesWharehouse::CONTACT_PHONE; ?>" value="<?php echo isset($wharehouse) ? $wharehouse->contactPhone : ""; ?>">
            </td>
        </tr>

    
    </tbody>
</table>