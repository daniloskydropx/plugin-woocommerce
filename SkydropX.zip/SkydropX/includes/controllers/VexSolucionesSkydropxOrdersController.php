<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */


class VexSolucionesSkydropxOrdersController {

    private static $instance = null;
    
    public static function getInstance() {
        if(self::$instance === null)
            self::$instance = new VexsolucionesSkydropxCheckoutController;
        return self::$instance;
    }
    
    public function orderDetailsAction() {
        $orderDetails = new VexsolucionesOrderDetails;
        add_action("woocommerce_admin_order_data_after_billing_address", [$orderDetails, "showCheckoutFieldsInAdminOrderDetails"], 10, 1);
        add_filter("woocommerce_order_formatted_billing_address", [$orderDetails, "addOrderBillingAddressDetail"], 10, 2);
        add_filter("woocommerce_order_formatted_shipping_address", [$orderDetails, "addOrderShippingAddressDetail"], 10, 2);
    }
    
}
