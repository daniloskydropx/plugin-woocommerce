<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

defined( 'ABSPATH' ) || exit;

class VexSolucionesSkydropxShippingMethod extends WC_Shipping_Method {

    const ID = "vex_soluciones_skydropx";
    const AVAILABLE_COUNTRIES = ["MX"];
    const MAX_WEIGHT = 30;
    const SHIPPING_STATE = "skydropx_shipping_state";
    const SHIPPING_SKYDROPX_TYPE = 'shipping_skydropx_type';

    public function __construct() {
        $this->id = self::ID; 
        $this->method_title = __( 'Método de Envío Skydropx', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN );  
        $this->method_description = __( 'El plugin de <a href="#"> Skydropx </a> para Woocommerce te permite conectar tu tienda online e-commerce con tu proveedor de Logística <a href="#"> Skydropx </a> en mínutos.', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN ); 
        $this->availability = 'including';
        $this->title = __( 'Método de Envío Skydropx', Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN );
        $this->countries = self::AVAILABLE_COUNTRIES;
        $this->enabled = "yes";
        $this->init();
    }

    function init() {
        // Load the settings API
        $this->init_form_fields(); 
        $this->init_settings(); 
        // Save settings in admin if you have any defined
        add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
    }
    
    public function generate_settings_html($form_fields=[], $echo=true) {
        ob_start();
        Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings()->renderSettingsPage();
        return ob_get_clean();
    }
    
    public function process_admin_options() {
        try {
            Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings()->save();
            return true;
        } catch(Exception $e) {
            Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings()->renderNotice(__("Error:", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN), $e->getMessage(), "error");
        }
        return false;
    }
    
    public function calculate_shipping($package=[]) {
        /* rates */
        $rate = array(
            'id'    => self::ID,   // ID for the rate
            'label' => __("Skydropx", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN),
            'cost'  => self::getCostSkydropx($package),
            // "calc_tax" => "per_order", // per_item
            // "taxes" => false // []
        );
        $this->add_rate($rate);
    }
    
    public static function doIfShippingIsSkydropx($callback) {
        $country = WC()->customer->get_shipping_country();
        foreach(WC()->session->get( 'chosen_shipping_methods' ) as $index => $selectedShippingMethod) {
            if(in_array($country, VexSolucionesSkydropxShippingMethod::AVAILABLE_COUNTRIES) && $selectedShippingMethod === self::ID) 
                $callback(WC()->cart->get_shipping_packages()[$index]);
        }
    }
    
    public static function getCostSkydropx($package, $shippingType=false) {
        $settings = self::getSettingsForPackage($package);
        $cost = 0; $data = [];
        if(array_key_exists("post_data", $_POST))
            parse_str($_POST["post_data"], $data);
        $lat = $data['lat'];
        $lgt = $data['lng'];
        $zip=$data['billing_postcode'];
        if($shippingType === false) 
            $shippingType = $data[VexSolucionesSkydropxShippingMethod::SHIPPING_SKYDROPX_TYPE];
     if(!empty($zip)) {
            $wharehouse = VexSolucionesWharehouse::getClosestWharehouse($settings->getWharehouses(), $lat, $lgt);
            // $distance = VexSolucionesUtils::getDistanceFromLatLonInKm($wharehouse->lat, $wharehouse->lgt, $lat, $lgt);
            $shippingType = intval($shippingType);
     
           // $returnToOrigin = $settings->returnToOrigin() == 'yes' ? 'true' : 'false';
             global $woocommerce;
                foreach(WC()->cart->get_cart() as $cart_item) { 
        // Get an instance of the WC_Product object and cart quantity
        $product = $cart_item['data'];
        $qty= $cart_item['quantity'];

        // Get product dimensions  
        $length = $product->get_length();
        $width  = $product->get_width();
        $height = $product->get_height();
       $weight = $product->get_weight();

        // Calculations a item level
        $totallength1=$length*$qty;
        $totalwidth1=$width*$qty;
        $totalheight1=$height*$qty;
       $totalweight1=$weight*$qty;
       $totallength+=$totallength1;
       $totalwidth+=$totalwidth1;
       $totalheight+=$totalheight1;
       $totalweight+=$totalweight1;

    } 
    if (empty($length) && empty($width) && empty($height) && empty($weight)) {
        wc_add_notice( 'Algunos de los productos en el carrito carece de información requerida', 'error' );
    }
$key=$settings->getSkydropxApiKey();
 $url = $settings->getEnvironmentMode() === 'enabled' ? 'https://sb-ecommerce-service.skydropx.com' : 'https://ecommerce-service.skydropx.com';
    $curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "{$url}/v1/rates",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "{\r\n  \"zip_from\": \"{$wharehouse->zip}\",\r\n  \"zip_to\": \"{$zip}\",\r\n  \"parcel\": {\r\n    \"weight\": {$totalweight},\r\n    \"height\": {$totalheight},\r\n    \"width\": {$totalwidth},\r\n    \"length\": {$totallength}\r\n  }\r\n}",
  CURLOPT_HTTPHEADER => array(
"authorization: token=".$key."",
    "Content-Type: application/json",
    "Accept: application/json"
  ),
));

$response = curl_exec($curl);
curl_close($curl);
    $response = json_decode($response, true);
      if($response) {
        if($response['success']==true)
        {
        $datos=$response['data'];
        $cuenta=count($datos);
       
        for ($i = 0; $i < $cuenta; ++$i)
        {
        
      //$response[$i]['provider'].' ('.$response[$i]['service_level_name'].'):'.$response[$i]['total_pricing'].' '.$response[$i]['service_level_code'].'<br>';
      /*switch($shippingType) {
        case $i: // Next Day
            $shippingType = $datos[$i]['service_level_code'];
            break;
    }*/

            if( $i == $shippingType) 
            {
                $cost= number_format($datos[$i]['total_pricing'], 2);
            }
        
        }
                  
            }
        }
            else
            {
                wc_add_notice( 'Ha ocurrido un error al comunicarse con skydropx', 'error' );
            } 
        
        }
            return $cost;

}
          /*  $url = $settings->getEnvironmentMode() === 'enabled' ? 'https://api-demo.skydropx.com' : 'https://api.skydropx.com';
            $urlCurl = "{$url}/v1/quotations";
            $curl = curl_init($urlCurl);
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, "{  
                \"zip_from\": 91000,
                \"zip_to\": 64000,
                \"parcel\": [
                    {\"weight\": \"10\"},
                    {\"height\": \"10\"},
                    {\"width\": \"10\"},
                    {\"length\": \"10\"}
                ],

            }");
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);                                                                    
            curl_setopt($curl, CURLOPT_HTTPHEADER, [                                                                       
                 "Authorization: Token token={$settings->getSkydropxApiKey()}",
                "Cache-Control: no-cache",
                "Content-Type: application/json"
                                                                                    
            ]);                                                                                                                                                                                                                                   
            $response = curl_exec($curl);
            $response = json_decode($response, true);
              foreach($response as $key => $value) {
                   
                        $precio= number_format($value['total_pricing'], 2);

                }
                $err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
return $precio;
}
       /*     if(is_array($response)) {
                $prices = $response['amount_local'];
                $provider= $response['provider'];
                $service= $response['service_level_name'];
                $preciofueradearea= $response['out_of_area_pricing'];
                 $totalp=$response['total_pricing'];
            }*/
      //  }
        

    
    /**
     * @return  VexSolucionesSkydropxSettings
     */
    public static function getSettingsForOrder($order) {
        $item = array_shift($order->get_items());
        $productItem = new WC_Order_Item_Product($item);
        $productPost = get_post($productItem->get_product()->get_id());
        $vendorId = $productPost->post_author;
        return Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings($vendorId);
    }
    
    // get the first product author within array of products in the package
    public static function getProductAuthorForPackage($package) {
        $oneItem = array_shift($package['contents']);
        $post = get_post($oneItem['product_id']);
        $vendorId = $post->post_author;
        return $vendorId;
    }
    
    /*
     * @return VexSolucionesSkydropxSettings
     */
    public static function getSettingsForPackage($package) {
        $author = self::getProductAuthorForPackage($package);
        return Vexsoluciones_Woocommerce_Skydropx::get_instance()->getSettings(user_can($author, 'administrator') ? false : $author);
    }

}

/* Disabled ajax checkout, for testing....
 * function disable_checkout_script(){
    wp_dequeue_script( 'wc-checkout' );
}
add_action( 'wp_enqueue_scripts', 'disable_checkout_script' ); */
