<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

class VexsolucionesOrderDetails {

    public function showCheckoutFieldsInAdminOrderDetails($order) {
        $skydropxStatus = get_post_meta($order->get_id(), 'skydropx_status', true);
        $skydropxCode = get_post_meta($order->get_id(), 'skydropx_code', true);
        $skydropxId = get_post_meta($order->get_id(), 'skydropx_id', true);
        $isSended = !empty($skydropxStatus) && !empty($skydropxCode) && !empty($skydropxId);
        if($isSended): ?>
            <p>
                <strong><?php echo __("Skydropx Order Id", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>:</strong><br> <?php echo $skydropxId; ?>
            </p>
           <!-- <p>
                <strong><?php echo __("Skydropx Code", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>:</strong><br> <?php echo $skydropxCode; ?>
            </p>
            <p>
                <strong><?php echo __("Skydropx Status", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN); ?>:</strong><br> <?php echo $skydropxStatus; ?>
            </p>-->
        <?php
        endif;
    }
    
    public function addOrderBillingAddressDetail($billing, $order) {
        return $billing;
    }
    
    public function addOrderShippingAddressDetail($shippingAddress, $order) {
        $skydropxStatus = get_post_meta($order->get_id(), 'skydropx_status', true);
        $skydropxCode = get_post_meta($order->get_id(), 'skydropx_code', true);
        $skydropxId = get_post_meta($order->get_id(), 'skydropx_id', true);
        $isSended = !empty($skydropxStatus) && !empty($skydropxCode) && !empty($skydropxId);
        if($isSended) {
            $shippingAddress["skydropx_id"] = $skydropxId;
            $shippingAddress["skydropx_code"] = $skydropxCode;
            $shippingAddress["skydropx_status"] = $skydropxStatus;
        }
        return $shippingAddress;
    }
    
}
