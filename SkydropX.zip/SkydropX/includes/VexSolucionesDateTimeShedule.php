<?php

/*
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */

class VexSolucionesDateTimeShedule {
    
    const CONF_NAME = "skydropx_shedule_days";
    
    const MONDAYSINCE = "mondaySince", MONDAYUNTIL = "mondayUntil", TUESDAYSINCE = "tuesdaySince";
    const TUESDAYUNTIL = "tuesdayUntil", WEDNESDAYSINCE = "wednesdaySince", WEDNESDAYUNTIL = "wednesdayUntil";
    const THURSDAYSINCE = "thursdaySince", THURSDAYUNTIL = "thursdayUntil", FRIDAYSINCE = "fridaySince";
    const FRIDAYUNTIL = "fridayUntil", SATURDAYSINCE = "saturdaySince", SATURDAYUNTIL = "saturdayUntil";
    const SUNDAYSINCE = "sundaySince", SUNDAYUNTIL = "sundayUntil";
    
    public $days;
    
    function __construct($days) {
        $this->days = $days;
        if(!$this->days) {
            $this->days = [
                "monday"=> [
                    "since" => "00:00",
                    "until" => "23:59"
                ],
                "tuesday"=> [
                    "since" => "00:00",
                    "until" => "23:59"
                ],
                "wednesday"=> [
                    "since" => "00:00",
                    "until" => "23:59"
                ],
                "thursday"=> [
                    "since" => "00:00",
                    "until" => "23:59"
                ],
                "friday"=> [
                    "since" => "00:00",
                    "until" => "23:59"
                ],
                "saturday"=> [
                    "since" => "00:00",
                    "until" => "23:59"
                ],
                "sunday"=> [
                    "since" => "00:00",
                    "until" => "23:59"
                ]
            ];
        }
    }
    
    public static function save() {
        $shedules = [];
        foreach(self::getFieldsNames() as $arg) {
            $checkName = str_replace(["Since", "Until"], "", $arg) . "LaborableDay";
            if(@empty($_POST[$arg]))
                continue;
            else if(@!isset($_POST[$checkName]) && @$_POST[$checkName] != 1)
                continue;
            $time = strtotime(@$_POST[$arg]);
            if($time !== false) {
                $dateTime = new DateTime();
                $dateTime->setTimestamp($time);
                $dayName = str_replace(["Since", "Until"], "", $arg);
                $sinceUntil = strtolower(str_replace($dayName, "", $arg));
                $shedules[$dayName][$sinceUntil] = $dateTime->format("H:i");
            } else
                throw new Exception(__("Se ha introducido una hora inválida", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN));
        }
        foreach($shedules as $key => $shedule) {
            if(strpos("Since", $key) !== false) {
                $dayName = str_replace(['Since', 'Until'], "", $key);
                if(!isset($shedule) || !isset($shedules[$dayName]["until"]))
                    throw new Exception(__("Cuando especificas uno de los tiempos para algún día, debes especificar ambos campos, si no queres colocar ese día como laborable, simplemente deja ambos vacíos.", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN));
                else if(strtotime($shedule) >= strtotime($shedules[$dayName]["until"]))
                    throw new Exception(__("El hora de inicio de la jornada ({$shedule}) no puede ser mayor o igual que la de finalización ({$shedules["{$dayName}Until"]})"));
            }
        }
        if(is_admin())
            update_option(self::CONF_NAME, $shedules);
        else
            update_user_meta(wp_get_current_user()->ID, self::CONF_NAME, $shedules);
    }
    
    public function timeIsIntoSheduleRange(DateTime $dateTimeShipping) {
        foreach($this->days as $dayName => $sinceUntil) {
            if($dayName == strtolower($dateTimeShipping->format("l"))) {
                $dateTimeShipping = new DateTime($dateTimeShipping->format("H:i"));
                $since = new DateTime("{$sinceUntil["since"]}");
                $until = new DateTime("{$sinceUntil["until"]}");
                // condition
                if($dateTimeShipping->getTimestamp() >= $since->getTimestamp() && $dateTimeShipping->getTimestamp() <= $until->getTimestamp())
                    return true;
            }
        }
        return false;
    }
    
    public function appendAllSchedulesToString(&$string) {
        $this->doForEachSchedule(function($dayName, $since, $until) use(&$string) {
            $string .= sprintf(__("%s de %s hasta las %s <br>", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN), VexSolucionesUtils::getDaysTranslated()[$dayName], $since->format("H:i"), $until->format("H:i"));
        });
    }
    
    public function haveScheduleConfigured() {
        $haveSchedule = false;
        $this->doForEachSchedule(function() use(&$haveSchedule) {
            $haveSchedule = true;
            return 1;
        });
        return $haveSchedule;
    }
    
    private function doForEachSchedule($callback) {
        foreach($this->days as $dayName => $untilSince) {
            $since = new DateTime("{$dayName} {$untilSince["since"]}");
            $until = new DateTime("{$dayName} {$untilSince["until"]}");
            $breakOrContinue = $callback($dayName, $since, $until);
            if($breakOrContinue === 1)
                break;
        }
    }
    
    public static function getFieldsNames() {
        return [
            self::MONDAYSINCE, self::MONDAYUNTIL, self::TUESDAYSINCE, self::TUESDAYUNTIL, 
            self::WEDNESDAYSINCE, self::WEDNESDAYUNTIL, self::THURSDAYSINCE, self::THURSDAYUNTIL, 
            self::FRIDAYSINCE, self::FRIDAYUNTIL, self::SATURDAYSINCE, self::SATURDAYUNTIL, 
            self::SUNDAYSINCE, self::SUNDAYUNTIL 
        ];
    }
    
    public static function getFieldName($field) {
        $key = str_replace(["Since", "Until"], "", $field);
        return VexSolucionesUtils::getDaysTranslated()[$key];
    }
    
    public static function getValueForFieldKey($instance, $field) {
        $dayName = str_replace(["Since", "Until"], "", $field);
        $sinceUntil = strtolower(str_replace($dayName, "", $field));
        $dayShedule = "";
        if(array_key_exists($dayName, $instance->days) && array_key_exists($sinceUntil, $instance->days[$dayName]))
            $dayShedule = $instance->days[$dayName][$sinceUntil];
        return $dayShedule;
    }
    
}
