<?php

/* 
 * * Woocommerce Skydropx
 * * https://www.pasarelasdepagos.com/
 * *
 * * Copyright (c) 2019 vexsoluciones
 * * Licensed under the GPLv2+ license.
 */
defined( 'ABSPATH' ) || exit;

class VexSolucionesSkydropxSettings {
    
    const SETTINGS_NONCE = "skydropx_save_settings_nonce", FLAT_PRICE_FIELD = "skydropx_flat_price_input";
    const ORDER_STATE = "skydropx_order_state", GOOGLE_API_KEY = 'skydropx_google_api_key', SERVICIOSGOO = 'skydropx_servicios_google';
    const API_KEY = "skydropx_api_key", SANDBOX_MODE = 'skydropx_sandbox_mode', SHOPID ='skydropx_shopid';
   // const COST_FREE = "skydropx_cost_free", COST_FLAT = "skydropx_flat_price", COST_CALCULATE_AUTOMATIC = 'costo_calculado_automaticamente';
        const COST_CALCULATE_AUTOMATIC = 'costo_calculado_automaticamente';

    
    private static $instance = null;
    
    /**
    * @return VexSolucionesSkydropxSettings
    */
    public static function getInstance() {
        if(self::$instance === null)
            self::$instance = new VexSolucionesSkydropxSettings;
        return self::$instance;
    }
    
    private $author;

    function __construct($author=false) {
        $this->author = $author;
        if(isset($_GET['page']) && $_GET['page'] == 'wc-settings' && $_GET['tab'] == 'shipping' && $_GET['section'] == 'vex_soluciones_skydropx') {
            add_action("admin_enqueue_scripts", [$this, 'enqueueScripts']);
        //   add_action("admin_enqueue_scripts", VexSolucionesUbigeoGoogleMap::class . '::scripts');
        }
    }
    
    public function getWharehouses() {
        $dbWharehouses = get_user_meta($this->author, VexSolucionesWharehouse::CONF_NAME, true);
        if(!$this->author || empty($dbWharehouses))
            $dbWharehouses =  get_option(VexSolucionesWharehouse::CONF_NAME, []);
        $wharehouses = [];
        foreach($dbWharehouses as $wharehouse) {
            $wharehouse = new VexSolucionesWharehouse($wharehouse);
            $wharehouses[] = $wharehouse;
        }
        return $wharehouses;
    }
    
    /**
    * @return VexSolucionesDateTimeShedule
    */
    public function getTimesShedules() {
        $days = get_user_meta($this->author, VexSolucionesDateTimeShedule::CONF_NAME, true);
        if(!$this->author || empty($days))
            $days = get_option(VexSolucionesDateTimeShedule::CONF_NAME, false);
        return new VexSolucionesDateTimeShedule($days);
    }
    
    public function getHolidaysShedules() {
        $dbHolidays = get_user_meta($this->author, VexSolucionesSheduleHoliday::CONF_NAME, true);
        if(!$this->author || empty($dbHolidays))
            $dbHolidays = get_option(VexSolucionesSheduleHoliday::CONF_NAME, []);
        $holidays = [];
        foreach($dbHolidays as $holiday) {
            $holiday = new VexSolucionesSheduleHoliday($holiday);
            $holidays[] = $holiday;
        }
        return $holidays;
    }
    
    public function getHolidaysSheduleOnlyTimes() {
        $holidays = [];
        foreach($this->getHolidaysShedules() as $holiday) {
            $unixtimestamp = strtotime($holiday->datetime);
            $date = new DateTime();
            $date->setTimestamp($unixtimestamp);
            $holidays[] = $date->format("Y-m-d");
        }
        return $holidays;
    }
    
    public function getDisabledWeekDays() {
        $daysBlocked = VexSolucionesUtils::getDaysTranslated(-1);
        $days = $this->getTimesShedules()->days;
        foreach($days as $dayName => $sinceUntil) {
            foreach($daysBlocked as $index => $dayNameBlocked) {
                if($dayNameBlocked == $dayName)
                    unset($daysBlocked[$index]);
            }
        }
        $daysIndexes = [];
        foreach($daysBlocked as $index => $blocked) {
            $x = $index+1;
            if($x == 7)
                $x = 0;
            $daysIndexes[] = $x;
        }
        return $daysIndexes;
    }
    
    public function getFlatPrice() {
        $price = get_user_meta($this->author, self::FLAT_PRICE_FIELD, true);
        if(!$this->author || empty($price))
            $price = get_option(self::FLAT_PRICE_FIELD, 0);
        return empty($price) ? 0 : $price;
    }
    
    public function getSkydropxApiKey() {
        $apiKey = get_user_meta($this->author, self::API_KEY, true);
        if(!$this->author || empty($apiKey))
            $apiKey = get_option(self::API_KEY, '');
        return empty($apiKey) ? '' : $apiKey;
    }
    
    public function getWoocommerceDefaultStatus() {
        $status = get_user_meta($this->author, self::ORDER_STATE, true);
        if(!$this->author || empty($status))
            $status = get_option(self::ORDER_STATE, '');
        return empty($status) ? 'wc-completed' : $status;
    }
     public function getApiKeyGoogle() {
        $apikeyg = get_option(self::GOOGLE_API_KEY, '');
        return empty($apikeyg) ? '' : $apikeyg;
    }
    public function getshopid() {
        $shopid = get_option(self::SHOPID, '');
        return empty($shopid) ? '' : $shopid;
    }
   
    public function save() {
        if(!wp_verify_nonce($_POST[self::SETTINGS_NONCE], basename(__FILE__)))
            return;
            //guardar info y generar consuta par registrar la shop
            if (get_option("skydrop_shop_register")==false) {
               $webhook=Vexsoluciones_Woocommerce_Skydropx::plugin_url().'/callback/webhook.php';
               $key=$_POST['skydropx_api_key']; 
                $curl = curl_init();
            $url=get_option('skydropx_sandbox_mode') === 'enabled' ? 'https://sb-ecommerce-service.skydropx.com/v1/shop' : 'https://ecommerce-service.skydropx.com/v1/shop';
            curl_setopt_array($curl, array(
              CURLOPT_URL => ''.$url.'',
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS =>'{"shop_reference":"'.$_POST[self::SHOPID].'","name":"'.$_POST['compania'].'","country":"MX","webhook":"'.$webhook.'","provider":"woocommerce"}
            ',
              CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Accept: application/json',
                'Authorization: token='.$key.'',
              ),
            ));
            
            $response = curl_exec($curl);
            $info = curl_getinfo($curl);
            curl_close($curl);

//var_dump($info["http_code"]);
//var_dump($response);
            if($info["http_code"]===200)
            {
                $datos = json_decode($response, true);
                $data = $datos['data'];
                $id=$data['_id'];
                $shop_id=$data['shop_reference'];
                update_option('skydrop_shop_register', 'resgitered');
                update_option(self::SHOPID, $id);
                update_option('skydrop_shop_reference', $shop_id);
                update_option($confname, $_POST[$confname]);
                VexSolucionesWharehouse::save();
                VexSolucionesDateTimeShedule::save();
                VexSolucionesSheduleHoliday::save();
                $mode = (int)$_POST[self::SANDBOX_MODE];
                $mode = $mode === 1 ? 'enabled' : 'disabled';
                $modegoogle = (int)$_POST[self::SERVICIOSGOO];
                $modegoogle = $modegoogle === 1 ? 'enabled' : 'disabled';

                
                if(!$this->author) {
                    update_option(self::API_KEY, $_POST[self::API_KEY]);
                    update_option('skydropx_webhook', Vexsoluciones_Woocommerce_Skydropx::plugin_url().'/callback/webhook.php');
                  
                    update_option(self::SANDBOX_MODE, $mode);
                    update_option(self::FLAT_PRICE_FIELD, $_POST[self::FLAT_PRICE_FIELD]);
                      update_option(self::GOOGLE_API_KEY, $_POST[self::GOOGLE_API_KEY]);
                      update_option(self::SERVICIOSGOO, $modegoogle);
                      
                    update_option(self::ORDER_STATE, $_POST[self::ORDER_STATE]);
                } else {
                    update_user_meta(wp_get_current_user()->ID, self::API_KEY, $_POST[self::API_KEY]);
                   
                    update_user_meta(wp_get_current_user()->ID, self::SANDBOX_MODE, $mode);
                    update_user_meta(wp_get_current_user()->ID, self::FLAT_PRICE_FIELD, $_POST[self::FLAT_PRICE_FIELD]);
                     update_user_meta(wp_get_current_user()->ID, self::GOOGLE_API_KEY, $_POST[self::GOOGLE_API_KEY]);
                     update_user_meta(wp_get_current_user()->ID, self::SERVICIOSGOO, $modegoogle);
                    update_user_meta(wp_get_current_user()->ID, self::ORDER_STATE, $_POST[self::ORDER_STATE]);
                }
                foreach(apply_filters('additional_configuration', []) as $confname)
                    update_option($confname, $_POST[$confname]);
                $this->renderNotice(__("Correcto", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN), __("La información ha sido guardada/actualizada con exíto."), "success");
                
            }
            else
            {
                $this->renderNotice(__("Error", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN), __("Ha ocurrido un error al comunicarse con skydropx."), "error");
                return;
            }
                
            }
            //guardar sin registrar la tienda, debido a que ya esta guardado
            else{
                VexSolucionesWharehouse::save();
                VexSolucionesDateTimeShedule::save();
                VexSolucionesSheduleHoliday::save();
                $mode = (int)$_POST[self::SANDBOX_MODE];
                $mode = $mode === 1 ? 'enabled' : 'disabled';
                $modegoogle = (int)$_POST[self::SERVICIOSGOO];
                $modegoogle = $modegoogle === 1 ? 'enabled' : 'disabled';
        
                if(!$this->author) {
                    update_option(self::API_KEY, $_POST[self::API_KEY]);
                  //  update_option('skydropx_webhook', get_site_url().'/wp-content/plugins/vexsoluciones-woocommerce-skydropx/callback/webhook.php');
                    //update_option(self::SHOPID, $_POST[self::SHOPID]);
                    update_option(self::SANDBOX_MODE, $mode);
                    update_option(self::FLAT_PRICE_FIELD, $_POST[self::FLAT_PRICE_FIELD]);
                      update_option(self::GOOGLE_API_KEY, $_POST[self::GOOGLE_API_KEY]);
                      update_option(self::SERVICIOSGOO, $modegoogle);
                      
                    update_option(self::ORDER_STATE, $_POST[self::ORDER_STATE]);
                } else {
                    update_user_meta(wp_get_current_user()->ID, self::API_KEY, $_POST[self::API_KEY]);
                   // update_user_meta(wp_get_current_user()->ID, self::SHOPID, $_POST[self::SHOPID]);
                    update_user_meta(wp_get_current_user()->ID, self::SANDBOX_MODE, $mode);
                    update_user_meta(wp_get_current_user()->ID, self::FLAT_PRICE_FIELD, $_POST[self::FLAT_PRICE_FIELD]);
                     update_user_meta(wp_get_current_user()->ID, self::GOOGLE_API_KEY, $_POST[self::GOOGLE_API_KEY]);
                     update_user_meta(wp_get_current_user()->ID, self::SERVICIOSGOO, $modegoogle);
                    update_user_meta(wp_get_current_user()->ID, self::ORDER_STATE, $_POST[self::ORDER_STATE]);
                }
                foreach(apply_filters('additional_configuration', []) as $confname)
                    update_option($confname, $_POST[$confname]);
                $this->renderNotice(__("Correcto", Vexsoluciones_Woocommerce_Skydropx::TEXT_DOMAIN), __("La información ha sido guardada/actualizada con exíto."), "notice");

            }

    }
    
    public function getEnvironmentMode() {
        $mode = (int)get_user_meta($this->author, self::SANDBOX_MODE, true);
        if(!$this->author || empty($mode))
            $mode = get_option(self::SANDBOX_MODE, 'disabled');
        return empty($mode) ? 'disabled' : $mode;
    }
    public function servicesGoogle() {
        $modegoogle = (int)get_user_meta($this->author, self::SERVICIOSGOO, true);
        if(!$this->author || empty($modegoogle))
            $modegoogle = get_option(self::SERVICIOSGOO, '');
        return empty($modegoogle) ? 'disabled' : $modegoogle;
    }
    

    
    public function renderSettingsPage() {
        $page = null;
        $views = apply_filters('skydropx_settings_views', [
            ['name' => 'settingsDefaultOrderState', 'path' => Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . '/views', 'priority' => 700],
            ['name' => 'settingsApiSkydropxParamsTable', 'path' => Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . '/views', 'priority' => 600],
            ['name' => 'settingsScheduleWorkDaysTable', 'path' => Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . '/views', 'priority' => 500],
            ['name' => 'settingsHolidays', 'path' => Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . '/views', 'priority' => 400],
            ['name' => 'settingsWharehouses', 'path' => Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . '/views', 'priority' => 300]
        ]);
        for($i = 0; $i < count($views); $i++) {
            $interchange = false;
            for($j = 0; $j < count($views)-1; $j++) {
                if($views[$j]['priority'] < $views[$j+1]['priority']) {
                    $temp = $views[$j];
                    $views[$j] = $views[$j+1];
                    $views[$j+1] = $temp;
                    $interchange = true;
                }
            }
            if(!$interchange)
                break;
        }
        // Javascript 
        ob_start();
        include Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . "/views/dynamicTableRow.php";
        $restrictionRow = ob_get_clean();
        ob_start();
        include Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . "/views/warehouseTabLink.php";
        $tabLinkHtml = ob_get_clean();
        ob_start();
        include Vexsoluciones_Woocommerce_Skydropx::SKYDROPX_DIR . "/views/warehouseTab.php";
        $tabHtml = ob_get_clean(); ?>
        <script type="text/javascript">
            var tabLinkHtml = `<?php echo $tabLinkHtml; ?>`;
            var tabHtml = `<?php echo $tabHtml; ?>`;
            var dayNamesMin = JSON.parse(`<?php echo json_encode(VexSolucionesUtils::getDaysTranslated(1, 3)); ?>`);
            var monthNames = JSON.parse(`<?php echo json_encode(VexSolucionesUtils::getMonthsTraslated(1)); ?>`);
        </script>
        <?php
        ob_start();   
        for($h = 0; $h < count($views); $h++) {
            $view = $views[$h];
            $path = "{$view['path']}/{$view['name']}.php";
            include $path;
        }
        wp_nonce_field( basename( __FILE__ ), self::SETTINGS_NONCE);
        $page = ob_get_clean();
        echo $page;
        /*$validate=get_option('skydropx_licensia');
        if(!empty($validate))
        {
            
        }*/
    }
    
    public function renderNotice($title, $desc, $class) { ?>
        <div class="<?php echo $class; ?>"><p><strong><?php echo $title; ?>:</strong> <?php echo $desc; ?></p></div>
    <?php
    }
    
     public function enqueueScripts() {
        // JQuery UI
        wp_enqueue_style("jquery-ui.css", Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/jquery-ui/jquery-ui.min.css');
        wp_enqueue_script('jquery-ui', Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/jquery-ui/jquery-ui.min.js', array('jquery'), Vexsoluciones_Woocommerce_Skydropx::VERSION, true);
        wp_enqueue_style("skydropx-admin-styles", Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/css/admin-styles.css');
        /* Libaries */
        wp_enqueue_style("select2.css", Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/select2/select2.min.css');
        wp_enqueue_script('select2.', Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/select2/select2.full.min.js', array('jquery'), Vexsoluciones_Woocommerce_Skydropx::VERSION, true);
        wp_enqueue_script('jquery-czmore', Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/js/jquery.czMore-1.5.3.2.js', array('jquery'), Vexsoluciones_Woocommerce_Skydropx::VERSION, true);
        /* Datetime Picker */
        wp_enqueue_style("datetimepicker.css", Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/datetimepicker/jquery.datetimepicker.min.css');
        wp_enqueue_script('datetimepicker', Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/datetimepicker/jquery.datetimepicker.full.min.js', array('jquery'), Vexsoluciones_Woocommerce_Skydropx::VERSION, true);
        wp_enqueue_script('skydropxSettings', Vexsoluciones_Woocommerce_Skydropx::plugin_url() . '/assets/js/settings.js', array('jquery', 'jquery-ui', 'datetimepicker', 'jquery-czmore', 'select2'), Vexsoluciones_Woocommerce_Skydropx::VERSION, true);
    }


   
}
